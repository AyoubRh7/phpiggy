<?php
// report all the  PHP errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

// datenbank configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'azubis_2025');
define('DB_USER', 'root');
define('DB_PASS', '');

// Jwt configuration
define('SECRET_KEY', 'GenZAzubis2025');
define('TOKEN_EXPIRY', 3600 * 24); // 1 day (in seconds)

// avoid cors problems in frontend localhost
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Max-Age: 3600');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// handle OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

?>