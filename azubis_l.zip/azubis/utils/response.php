<?php
/**
 * Standardizes API responses and sends JSON output.
 */
function sendResponse(int $status, $data = [], string $message = '') {
    http_response_code($status);

    $response = [
        'status' => $status,
        'success' => $status >= 200 && $status < 300,
        'message' => $message,
        'data' => $data,
    ];

    echo json_encode($response);
    exit;
}
?>