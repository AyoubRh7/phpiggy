<?php
/**
 * Creates a simple base64 encoded token (simulating JWT).
 */
function createToken(array $payload): string {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload['exp'] = time() + TOKEN_EXPIRY;
    $payload_encoded = json_encode($payload);

    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload_encoded));

    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, SECRET_KEY, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

/**
 * Validates a simple token and returns the payload if valid.
 */
function validateToken(PDO $pdo): array|bool {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (empty($authHeader) || !preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        return false;
    }

    $token = $matches[1];
    $parts = explode('.', $token);

    if (count($parts) !== 3) {
        return false;
    }

    list($header, $payload_encoded, $signature) = $parts;

    // Verify Signature
    $expected_signature = hash_hmac('sha256', $header . "." . $payload_encoded, SECRET_KEY, true);
    $base64UrlExpectedSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($expected_signature));

    if ($signature !== $base64UrlExpectedSignature) {
        return false;
    }

    // Decode Payload and check expiry
    $payload_json = base64_decode(str_replace(['-', '_'], ['+', '/'], $payload_encoded));
    $payload = json_decode($payload_json, true);

    if (!$payload || !isset($payload['exp']) || $payload['exp'] < time() || !isset($payload['user_id'])) {
        return false;
    }

    // Basic user existence check
    $stmt = $pdo->prepare("SELECT user_id, role FROM benutzer WHERE user_id = ?");
    $stmt->execute([$payload['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        return false;
    }

    return ['user_id' => $user['user_id'], 'role' => $user['role']];
}

/**
 * Hashes a password using a secure algorithm.
 */
function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_DEFAULT);
}
?>