<?php
// Note: Models are injected via constructor in index.php

class TaskController {
    private TaskModel $taskModel;
    private UserModel $userModel;

    public function __construct(TaskModel $taskModel, UserModel $userModel) {
        $this->taskModel = $taskModel;
        $this->userModel = $userModel;
    }

    // --- AZUBI ENDPOINTS ---

    public function getAzubiTasks(int $azubiId) {
        $tasks = $this->taskModel->getTasksByAzubiId($azubiId);
        sendResponse(200, $tasks, "Azubi tasks retrieved successfully.");
    }

    public function getAzubiCompletedTasks(int $azubiId) {
        $tasks = $this->taskModel->getAzubiCompletedTasks($azubiId);
        sendResponse(200, $tasks, "Azubi completed tasks retrieved successfully.");
    }

    public function getAzubiTaskContent(int $taskId, int $userId, string $userRole) {
        $task = $this->taskModel->getAzubiTaskContent($taskId, $userId);

        if (!$task) {
            sendResponse(404, [], "Task content not found or unauthorized access.");
        }
        sendResponse(200, $task, "Task content retrieved.");
    }
    
    public function submitTask(int $taskId, int $azubiId, array $data, array $file) {
        $submissionText = $data['submission_text'] ?? NULL;
        $filePath = NULL;
        
        if (isset($file['submission_file']) && $file['submission_file']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }
            
            $extension = pathinfo($file['submission_file']['name'], PATHINFO_EXTENSION);
            if (!in_array(strtolower($extension), ['pdf', 'docx', 'doc', 'txt'])) {
                 sendResponse(400, [], "Unsupported file type. Only PDF, DOCX, DOC, and TXT are allowed.");
            }
            
            $fileName = $azubiId . '_' . $taskId . '_' . time() . '.' . $extension;
            $destination = $uploadDir . $fileName;

            if (move_uploaded_file($file['submission_file']['tmp_name'], $destination)) {
                $filePath = $destination;
            } else {
                sendResponse(500, [], "File upload failed.");
            }
        }

        if (empty($submissionText) && empty($filePath)) {
            sendResponse(400, [], "A text answer or file upload is required for submission.");
        }

        if ($this->taskModel->submitTask($taskId, $azubiId, $submissionText, $filePath)) {
            sendResponse(200, [], "Task submitted successfully.");
        } else {
            sendResponse(500, [], "An error occurred during submission.");
        }
    }


    // --- UNTERWEISER ENDPOINTS ---

    public function getAzubisList(int $unterweiserId) {
        $azubis = $this->userModel->getAzubisListForDropdown($unterweiserId);
        sendResponse(200, $azubis, "Assigned Azubis list retrieved successfully.");
    }

    public function assignNewTask(int $unterweiserId, array $data) {
        $azubiId = $data['azubi_id'] ?? NULL;
        $taskName = $data['task_name'] ?? '';
        $description = $data['description'] ?? '';
        $dueDate = $data['due_date'] ?? NULL;

        if (empty($azubiId) || empty($taskName) || empty($description)) {
            sendResponse(400, [], "Azubi ID, task name, and description are required.");
        }

        if (!$this->userModel->isAzubiManagedBy($azubiId, $unterweiserId)) {
            sendResponse(403, [], "Unauthorized: Azubi not managed by this Unterweiser.");
        }

        if ($this->taskModel->createTask($unterweiserId, $azubiId, $taskName, $description, $dueDate)) {
            sendResponse(201, [], "New task assigned successfully.");
        } else {
            sendResponse(500, [], "An error occurred while assigning the task.");
        }
    }

    public function getUnterweiserCompletedTasksForAzubi(int $unterweiserId, int $azubiId) {
        if (!$this->userModel->isAzubiManagedBy($azubiId, $unterweiserId)) {
            sendResponse(403, [], "Unauthorized: Cannot view tasks for this Azubi.");
        }
        
        $tasks = $this->taskModel->getCompletedTasksByAzubiForUnterweiser($unterweiserId, $azubiId);
        sendResponse(200, $tasks, "Completed tasks for Azubi ID {$azubiId} retrieved.");
    }
    
    public function getAzubiSubmissionAndFeedback(int $taskId, int $unterweiserId) {
        $submission = $this->taskModel->getAzubiSubmissionContent($taskId, $unterweiserId);

        if (!$submission) {
            sendResponse(404, [], "Submission not found or unauthorized access.");
        }
        sendResponse(200, $submission, "Azubi submission retrieved.");
    }

    public function reviewSubmission(int $taskId, int $unterweiserId, array $data) {
        $status = $data['status'] ?? ''; 
        $notes = $data['notes'] ?? NULL; // The Feedback

        if (!in_array($status, ['completed', 'in_progress', 'submitted'])) {
            sendResponse(400, [], "Invalid status provided.");
        }

        if ($this->taskModel->updateTaskReview($taskId, $unterweiserId, $status, $notes)) {
            sendResponse(200, [], "Task review and feedback updated successfully.");
        } else {
            sendResponse(403, [], "Unauthorized or task not found.");
        }
    }
}

