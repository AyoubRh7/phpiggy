<?php
// Load configuration and CORS headers
require_once 'config.php';
// Load utilities
require_once 'utils/response.php';
require_once 'utils/auth.php';
// Load core classes
require_once 'classes/Database.php';
// Load models
require_once 'models/UserModel.php';
require_once 'models/TaskModel.php';
// Load controllers
require_once 'controllers/UserController.php';
require_once 'controllers/TaskController.php';

$database = new Database();
$pdo = $database->getConnection();

$userModel = new UserModel($pdo);
$taskModel = new TaskModel($pdo);

$userController = new UserController($userModel);
$taskController = new TaskController($taskModel, $userModel);


// --- Request Handling ---
$method = $_SERVER['REQUEST_METHOD'];

$uri = $_SERVER['REQUEST_URI'];
$basePath = '/v1/'; 

$startPos = strpos($uri, $basePath);
if ($startPos === false) {
    $uri = ltrim($uri, '/');
} else {
    $uri = substr($uri, $startPos + strlen($basePath));
}

$uri_parts = explode('/', trim($uri, '/'));

$api_endpoint = $uri_parts[0] ?? ''; 
$resource_id = $uri_parts[1] ?? null;

$data = [];
if ($method === 'POST' || $method === 'PUT') {
    if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } else {
        $data = $_POST;
    }
}


// --- 1. Public Routes (No Authentication Required) ---
if ($api_endpoint === 'login' && $method === 'POST') {
    $userController->handleLogin($data);
}


// --- 2. Protected Routes (Authentication Required) ---
$auth = validateToken($pdo);
if (!$auth) {
    sendResponse(401, [], "Access Denied: Invalid or missing token.");
}

$userId = $auth['user_id'];
$userRole = trim ($auth['role']);


// --- 3. Role-Based Routing ---

if ($userRole === 'azubi') {
    switch ($api_endpoint) {
        case 'tasks':
            if ($method === 'GET' && is_null($resource_id)) {
                $taskController->getAzubiTasks($userId);
            }
            break;
        case 'azubi':
            if ($method === 'GET' && $resource_id === 'tasks' && ($uri_parts[2] ?? '') === 'completed') {
                $taskController->getAzubiCompletedTasks($userId);
            }
            break;
        case 'task':
            $taskId = (int)$resource_id;
            if ($method === 'GET' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'content') {
                $taskController->getAzubiTaskContent($taskId, $userId, $userRole);
            } elseif ($method === 'POST' && $resource_id === 'submit' && isset($uri_parts[2])) {
                $taskId = (int)$uri_parts[2];
                $taskController->submitTask($taskId, $userId, $_POST, $_FILES);
            }
            break;
    }

} elseif ($userRole === 'unterweiser') {
    switch ($api_endpoint) {
        case 'azubis':
            if ($method === 'GET' && $resource_id === 'list') {
                $taskController->getAzubisList($userId);
            }
            break;
        case 'azubi':
            $azubiId = (int)$resource_id;
            if ($method === 'GET' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'tasks' && ($uri_parts[3] ?? '') === 'completed') {
                $taskController->getUnterweiserCompletedTasksForAzubi($userId, $azubiId);
            }
            break;
        case 'task':
            $taskId = (int)$resource_id;
            if ($method === 'POST' && is_null($resource_id)) {
                $taskController->assignNewTask($userId, $data);
            } elseif ($method === 'GET' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'submission') {
                 $taskController->getAzubiSubmissionAndFeedback($taskId, $userId);
            } elseif ($method === 'PUT' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'review') {
                $taskController->reviewSubmission($taskId, $userId, $data);
            }
            break;
    }
}

// Default route for unsupported endpoints
sendResponse(404, [], "Endpoint not found or method not allowed.");
?>