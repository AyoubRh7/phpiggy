<?php
class TaskModel {
    private PDO $conn;
    private string $tasks_table = "tasks";
    private string $submissions_table = "submissions";

    public function __construct(PDO $db) {
        $this->conn = $db;
    }

    // --- Azubi Specific ---

    public function getTasksByAzubiId(int $azubiId): array {
        $query = "SELECT t.task_id, t.task_name, t.status, t.due_date, 
                         CONCAT(b.first_name, ' ', b.last_name) AS unterweiser_name
                  FROM {$this->tasks_table} t
                  JOIN benutzer b ON t.unterweiser_id = b.user_id
                  WHERE t.azubi_id = ?
                  ORDER BY t.assigned_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$azubiId]);
        return $stmt->fetchAll();
    }
    
    public function getAzubiCompletedTasks(int $azubiId): array {
        $query = "SELECT t.task_id, t.task_name, t.due_date, 
                         CONCAT(b.first_name, ' ', b.last_name) AS unterweiser_name,
                         s.unterweiser_notes 
                  FROM {$this->tasks_table} t
                  JOIN benutzer b ON t.unterweiser_id = b.user_id
                  LEFT JOIN {$this->submissions_table} s ON t.task_id = s.task_id
                  WHERE t.azubi_id = ? AND t.status = 'completed'
                  ORDER BY t.assigned_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$azubiId]);
        return $stmt->fetchAll();
    }
    
    public function getAzubiTaskContent(int $taskId, int $azubiId): array|false {
        $query = "SELECT task_name, description, assigned_date, due_date
                  FROM {$this->tasks_table}
                  WHERE task_id = ? AND azubi_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$taskId, $azubiId]);
        return $stmt->fetch();
    }

    public function submitTask(int $taskId, int $azubiId, string|null $submissionText, string|null $filePath): bool {
        try {
            $this->conn->beginTransaction();
            
            $checkStmt = $this->conn->prepare("SELECT submission_id FROM {$this->submissions_table} WHERE task_id = ?");
            $checkStmt->execute([$taskId]);
            $existing = $checkStmt->fetch();

            if ($existing) {
                $updateSql = "UPDATE {$this->submissions_table} SET submission_text=?, submission_file_path=?, submission_date=NOW(), unterweiser_notes=NULL WHERE task_id = ?";
                $this->conn->prepare($updateSql)->execute([$submissionText, $filePath, $taskId]);
            } else {
                $insertSql = "INSERT INTO {$this->submissions_table} (task_id, azubi_id, submission_text, submission_file_path, submission_date) VALUES (?, ?, ?, ?, NOW())";
                $this->conn->prepare($insertSql)->execute([$taskId, $azubiId, $submissionText, $filePath]);
            }

            $updateTaskSql = "UPDATE {$this->tasks_table} SET status = 'submitted' WHERE task_id = ?";
            $this->conn->prepare($updateTaskSql)->execute([$taskId]);

            $this->conn->commit();
            return true;
        } catch (\PDOException $e) {
            $this->conn->rollBack();
            error_log("Task submission error: " . $e->getMessage());
            return false;
        }
    }

    // --- Unterweiser Specific ---

    public function getCompletedTasksByAzubiForUnterweiser(int $unterweiserId, int $azubiId): array {
        $query = "SELECT t.task_id, t.task_name, t.assigned_date, s.submission_date, s.unterweiser_notes
                  FROM {$this->tasks_table} t
                  LEFT JOIN {$this->submissions_table} s ON t.task_id = s.task_id
                  WHERE t.unterweiser_id = ? AND t.azubi_id = ? AND t.status = 'completed'
                  ORDER BY t.assigned_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$unterweiserId, $azubiId]);
        return $stmt->fetchAll();
    }
    
    public function getAzubiSubmissionContent(int $taskId, int $unterweiserId): array|false {
        $query = "SELECT t.task_id, t.task_name, t.description, t.status,
                         s.submission_text, s.submission_file_path, s.submission_date, s.unterweiser_notes
                  FROM {$this->tasks_table} t
                  LEFT JOIN {$this->submissions_table} s ON t.task_id = s.task_id
                  WHERE t.task_id = ? AND t.unterweiser_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$taskId, $unterweiserId]);
        return $stmt->fetch();
    }
    
    public function createTask(int $unterweiserId, int $azubiId, string $taskName, string $description, string|null $dueDate): bool {
        $query = "INSERT INTO {$this->tasks_table} (task_name, description, unterweiser_id, azubi_id, due_date)
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$taskName, $description, $unterweiserId, $azubiId, $dueDate]);
    }
    
    public function updateTaskReview(int $taskId, int $unterweiserId, string $status, string|null $notes): bool {
        try {
            $this->conn->beginTransaction();

            $updateTaskSql = "UPDATE {$this->tasks_table} SET status = ? WHERE task_id = ? AND unterweiser_id = ?";
            $taskResult = $this->conn->prepare($updateTaskSql)->execute([$status, $taskId, $unterweiserId]);

            $updateSubmissionSql = "UPDATE {$this->submissions_table} SET unterweiser_notes = ? WHERE task_id = ?";
            $this->conn->prepare($updateSubmissionSql)->execute([$notes, $taskId]);

            $this->conn->commit();
            return $taskResult;
        } catch (\PDOException $e) {
            $this->conn->rollBack();
            error_log("Task review update error: " . $e->getMessage());
            return false;
        }
    }
}

