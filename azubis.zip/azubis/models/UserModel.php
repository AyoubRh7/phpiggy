<?php
class UserModel {
    private PDO $conn;
    private string $table_name = "benutzer";

    public function __construct(PDO $db) {
        $this->conn = $db;
    }

    /**
     * Finds a user by username and verifies the password.
     */
    public function authenticate(string $username, string $password): array|false {
        $query = "SELECT user_id, password, role FROM " . $this->table_name . " WHERE username = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            return [
                'user_id' => $user['user_id'],
                'role' => $user['role']
            ];
        }
        return false;
    }

    /**
     * Retrieves all Azubis associated with a specific Unterweiser.
     */
    public function getAzubisByUnterweiser(int $unterweiserId): array {
        $query = "SELECT user_id, first_name, last_name, username 
                  FROM " . $this->table_name . " 
                  WHERE role = 'azubi' AND unterweiser_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$unterweiserId]);
        return $stmt->fetchAll();
    }

    /**
     * Checks if a specific Azubi is managed by a specific Unterweiser.
     */
    public function isAzubiManagedBy(int $azubiId, int $unterweiserId): bool {
        $query = "SELECT user_id FROM " . $this->table_name . " WHERE user_id = ? AND unterweiser_id = ? AND role = 'azubi'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$azubiId, $unterweiserId]);
        return $stmt->rowCount() > 0;
    }
}
?>