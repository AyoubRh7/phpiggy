<?php
class TaskModel {
    private PDO $conn;
    private string $tasks_table = "tasks";
    private string $submissions_table = "submissions";

    public function __construct(PDO $db) {
        $this->conn = $db;
    }

    // --- Azubi Specific ---
    public function getTasksByAzubiId(int $azubiId): array {
        $query = "SELECT t.*, u.first_name AS unterweiser_vorname , u.last_name AS unterweiser_name
                  FROM {$this->tasks_table} t
                  LEFT JOIN users u ON t.unterweiser_id = u.user_id
                  WHERE t.azubi_id = ?
                  ORDER BY t.assigned_date DESC";
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$azubiId]);
            return $stmt->fetchAll();
        } catch (\PDOException $e) {
            error_log("Error fetching tasks by Azubi ID: " . $e->getMessage());
            sendResponse(500, [], "Internal Server Error");
            return [];
        }
    }

    public function getTaskDetails(int $taskId, int $userId, string $userRole): array|false {
        $role_field = ($userRole === 'azubi') ? 't.azubi_id' : 't.unterweiser_id';

        $query = "SELECT t.*, s.submission_text, s.submission_file_path, s.unterweiser_notes
                  FROM {$this->tasks_table} t
                  LEFT JOIN {$this->submissions_table} s ON t.task_id = s.task_id
                  WHERE t.task_id = ? AND $role_field = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$taskId, $userId]);
        return $stmt->fetch();
    }
    
    public function submitTask(int $taskId, int $azubiId, string|null $submissionText, string|null $filePath): bool {
        try {
            $this->conn->beginTransaction();
            
            $checkStmt = $this->conn->prepare("SELECT submission_id FROM {$this->submissions_table} WHERE task_id = ?");
            $checkStmt->execute([$taskId]);
            $existing = $checkStmt->fetch();

            if ($existing) {
                $updateSql = "UPDATE {$this->submissions_table} SET submission_text=?, submission_file_path=?, submission_date=NOW(), unterweiser_notes=NULL WHERE task_id = ?";
                $this->conn->prepare($updateSql)->execute([$submissionText, $filePath, $taskId]);
            } else {
                $insertSql = "INSERT INTO {$this->submissions_table} (task_id, azubi_id, submission_text, submission_file_path, submission_date) VALUES (?, ?, ?, ?, NOW())";
                $this->conn->prepare($insertSql)->execute([$taskId, $azubiId, $submissionText, $filePath]);
            }

            $updateTaskSql = "UPDATE {$this->tasks_table} SET status = 'submitted' WHERE task_id = ?";
            $this->conn->prepare($updateTaskSql)->execute([$taskId]);

            $this->conn->commit();
            return true;
        } catch (\PDOException $e) {
            $this->conn->rollBack();
            error_log("Task submission error: " . $e->getMessage());
            return false;
        }
    }

    // --- Unterweiser Specific ---
    
    public function getAzubiTasksForUnterweiser(int $unterweiserId, int $azubiId): array {
        $query = "SELECT t.*, s.submission_date 
                  FROM {$this->tasks_table} t
                  LEFT JOIN {$this->submissions_table} s ON t.task_id = s.task_id
                  WHERE t.unterweiser_id = ? AND t.azubi_id = ?
                  ORDER BY t.assigned_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$unterweiserId, $azubiId]);
        return $stmt->fetchAll();
    }
    
    public function createTask(int $unterweiserId, int $azubiId, string $taskName, string $description, string|null $dueDate): bool {
        $query = "INSERT INTO {$this->tasks_table} (task_name, description, unterweiser_id, azubi_id, due_date)
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$taskName, $description, $unterweiserId, $azubiId, $dueDate]);
    }
    
    public function evaluateTask(int $taskId, int $unterweiserId, string $status, string|null $notes): bool {
        try {
            $this->conn->beginTransaction();

            $updateTaskSql = "UPDATE {$this->tasks_table} SET status = ? WHERE task_id = ? AND unterweiser_id = ?";
            $taskResult = $this->conn->prepare($updateTaskSql)->execute([$status, $taskId, $unterweiserId]);

            $updateSubmissionSql = "UPDATE {$this->submissions_table} SET unterweiser_notes = ? WHERE task_id = ?";
            $this->conn->prepare($updateSubmissionSql)->execute([$notes, $taskId]);

            $this->conn->commit();
            return $taskResult;
        } catch (\PDOException $e) {
            $this->conn->rollBack();
            error_log("Task evaluation error: " . $e->getMessage());
            return false;
        }
    }
}
?>