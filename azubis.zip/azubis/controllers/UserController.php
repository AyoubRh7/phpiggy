<?php
// Note: UserModel is injected via constructor in index.php

class UserController {
    private UserModel $userModel;

    public function __construct(UserModel $userModel) {
        $this->userModel = $userModel;
    }

    public function handleLogin(array $data) {
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($username) || empty($password)) {
            sendResponse(400, [], "Username and password are required.");
        }

        $authData = $this->userModel->authenticate($username, $password);

        if (!$authData) {
            sendResponse(401, [], "Invalid credentials.");
        }

        // Authentication successful, create token
        $token = createToken($authData);

        sendResponse(200, [
            'token' => $token,
            'user_id' => $authData['user_id'],
            'role' => $authData['role']
        ], "Login successful.");
    }
}
?>