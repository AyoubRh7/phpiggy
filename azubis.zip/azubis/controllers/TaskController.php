<?php
// Note: Models are injected via constructor in index.php

class TaskController {
    private TaskModel $taskModel;
    private UserModel $userModel;

    public function __construct(TaskModel $taskModel, UserModel $userModel) {
        $this->taskModel = $taskModel;
        $this->userModel = $userModel;
    }

    // --- Azubi Endpoints ---

    public function getAzubiTasks(int $azubiId) {
        $tasks = $this->taskModel->getTasksByAzubiId($azubiId);
        sendResponse(200, $tasks, "Azubi tasks retrieved successfully.");
    }

    public function getTaskDetails(int $taskId, int $userId, string $userRole) {
        $task = $this->taskModel->getTaskDetails($taskId, $userId, $userRole);

        if (!$task) {
            sendResponse(404, [], "Task not found or unauthorized access.");
        }
        sendResponse(200, $task, "Task details retrieved.");
    }

    public function submitTask(int $taskId, int $azubiId, array $data, array $file) {
        $submissionText = $data['submission_text'] ?? NULL;
        $filePath = NULL;
        
        // Handle file upload
        if (isset($file['submission_file']) && $file['submission_file']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                // Ensure 'uploads/' folder is created in the API root
                mkdir($uploadDir, 0777, true); 
            }
            $extension = pathinfo($file['submission_file']['name'], PATHINFO_EXTENSION);
            
            if (!in_array(strtolower($extension), ['pdf', 'docx', 'doc', 'txt'])) {
                 sendResponse(400, [], "Unsupported file type. Only PDF, DOCX, DOC, and TXT are allowed.");
            }
            
            $fileName = $azubiId . '_' . $taskId . '_' . time() . '.' . $extension;
            $destination = $uploadDir . $fileName;

            if (move_uploaded_file($file['submission_file']['tmp_name'], $destination)) {
                $filePath = $destination;
            } else {
                sendResponse(500, [], "File upload failed.");
            }
        }

        if (empty($submissionText) && empty($filePath)) {
            sendResponse(400, [], "A text answer or file upload is required for submission.");
        }

        if ($this->taskModel->submitTask($taskId, $azubiId, $submissionText, $filePath)) {
            sendResponse(200, [], "Task submitted successfully.");
        } else {
            sendResponse(500, [], "An error occurred during submission.");
        }
    }

    // --- Unterweiser Endpoints ---

    public function getUnterweiserAzubis(int $unterweiserId) {
        $azubis = $this->userModel->getAzubisByUnterweiser($unterweiserId);
        sendResponse(200, $azubis, "Assigned Azubis retrieved successfully.");
    }

    public function getAzubiTasksForUnterweiser(int $unterweiserId, int $azubiId) {
        // Security check: Ensure the Unterweiser is authorized to view this Azubi's tasks
        if (!$this->userModel->isAzubiManagedBy($azubiId, $unterweiserId)) {
            sendResponse(403, [], "Unauthorized: Cannot view tasks for this Azubi.");
        }
        
        $tasks = $this->taskModel->getAzubiTasksForUnterweiser($unterweiserId, $azubiId);
        sendResponse(200, $tasks, "Tasks for Azubi ID {$azubiId} retrieved.");
    }
    
    public function assignNewTask(int $unterweiserId, array $data) {
        $azubiId = $data['azubi_id'] ?? NULL;
        $taskName = $data['task_name'] ?? '';
        $description = $data['description'] ?? '';
        $dueDate = $data['due_date'] ?? NULL;

        if (empty($azubiId) || empty($taskName) || empty($description)) {
            sendResponse(400, [], "Azubi ID, task name, and description are required.");
        }

        // Security Check: Ensure the Azubi is managed by this Unterweiser
        if (!$this->userModel->isAzubiManagedBy($azubiId, $unterweiserId)) {
            sendResponse(403, [], "Unauthorized: Azubi not managed by this Unterweiser.");
        }

        if ($this->taskModel->createTask($unterweiserId, $azubiId, $taskName, $description, $dueDate)) {
            sendResponse(201, [], "New task assigned successfully.");
        } else {
            sendResponse(500, [], "An error occurred while assigning the task.");
        }
    }

    public function evaluateTask(int $taskId, int $unterweiserId, array $data) {
        $status = $data['status'] ?? ''; // 'completed' or 'in_progress'
        $notes = $data['notes'] ?? NULL;

        if (!in_array($status, ['completed', 'in_progress'])) {
            sendResponse(400, [], "Invalid status provided. Must be 'completed' or 'in_progress'.");
        }

        if ($this->taskModel->evaluateTask($taskId, $unterweiserId, $status, $notes)) {
            sendResponse(200, [], "Task evaluation updated successfully.");
        } else {
            // This 403 usually means the task ID does not belong to the authenticated Unterweiser
            sendResponse(403, [], "Unauthorized or task not found.");
        }
    }
}
?>