<?php
// Load configuration and CORS headers
require_once 'config.php';
// Load utilities
require_once 'utils/response.php';
require_once 'utils/auth.php';
// Load core classes
require_once 'classes/Database.php';
// Load models
require_once 'models/UserModel.php';
require_once 'models/TaskModel.php';
// Load controllers
require_once 'controllers/UserController.php';
require_once 'controllers/TaskController.php';


// --- Initialization ---
$database = new Database();
$pdo = $database->getConnection();

// Instantiate Models
$userModel = new UserModel($pdo);
$taskModel = new TaskModel($pdo);

// Instantiate Controllers, injecting necessary Models
$userController = new UserController($userModel);
$taskController = new TaskController($taskModel, $userModel);


// --- Request Handling ---
$method = $_SERVER['REQUEST_METHOD'];

// Get URI parts. 
$uri = $_SERVER['REQUEST_URI'];
$basePath = '/v1/'; 
// Extract the path after /v1/ or the root if /v1/ is not found
$startPos = strpos($uri, $basePath);
if ($startPos === false) {
    $uri = ltrim($uri, '/');
} else {
    $uri = substr($uri, $startPos + strlen($basePath));
}

$uri_parts = explode('/', trim($uri, '/'));

$api_endpoint = $uri_parts[0] ?? ''; 
$resource_id = $uri_parts[1] ?? null;

// Get data from request body (for POST/PUT)
$data = [];
if ($method === 'POST' || $method === 'PUT') {
    if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } else {
        // For forms/uploads (like task submission)
        $data = $_POST;
    }
}


// --- 1. Public Routes (No Authentication Required) ---
if ($api_endpoint === 'login' && $method === 'POST') {
    $userController->handleLogin($data);
}


// --- 2. Protected Routes (Authentication Required) ---
$auth = validateToken($pdo);
if (!$auth) {
    sendResponse(401, [], "Access Denied: Invalid or missing token.");
}

$userId = $auth['user_id'];
$userRole = $auth['role'];


// --- 3. Role-Based Routing ---

if ($userRole === 'azubi') {
    // Azubi routes
    switch ($api_endpoint) {
        case 'tasks':
            if ($method === 'GET' && is_null($resource_id)) {
                // GET /v1/tasks
                $taskController->getAzubiTasks($userId);
            }
            break;
        case 'task':
            $taskId = (int)$resource_id;
            if ($method === 'GET' && !is_null($resource_id)) {
                // GET /v1/task/{id}
                $taskController->getTaskDetails($taskId, $userId, $userRole);
            } elseif ($method === 'POST' && $resource_id === 'submit' && isset($uri_parts[2])) {
                // POST /v1/task/submit/{task_id} - Submission via form-data (for file upload support)
                $taskId = (int)$uri_parts[2];
                // Note: $_POST and $_FILES are used for submissions with files
                $taskController->submitTask($taskId, $userId, $_POST, $_FILES);
            }
            break;
    }

} elseif ($userRole === 'unterweiser') {
    // Unterweiser routes
    switch ($api_endpoint) {
        case 'azubis':
            if ($method === 'GET') {
                // GET /v1/azubis
                $taskController->getUnterweiserAzubis($userId);
            }
            break;
        case 'azubi':
            if ($method === 'GET' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'tasks') {
                // GET /v1/azubi/{id}/tasks
                $taskController->getAzubiTasksForUnterweiser($userId, (int)$resource_id);
            }
            break;
        case 'task':
            $taskId = (int)$resource_id;
            if ($method === 'POST' && is_null($resource_id)) {
                // POST /v1/task - Assign a new task (JSON body)
                $taskController->assignNewTask($userId, $data);
            } elseif ($method === 'GET' && !is_null($resource_id)) {
                 // GET /v1/task/{id} - Get specific task details (for review)
                $taskController->getTaskDetails($taskId, $userId, $userRole);
            } elseif ($method === 'PUT' && !is_null($resource_id) && ($uri_parts[2] ?? '') === 'evaluate') {
                // PUT /v1/task/{id}/evaluate - Evaluate and set status/notes (JSON body)
                $taskController->evaluateTask($taskId, $userId, $data);
            }
            break;
    }
}

// Default route for unsupported endpoints
sendResponse(404, [], "Endpoint not found or method not allowed.");
?>